package com.example.nadoo.gallary;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.example.nadoo.gallary.R;

/**
 * Created by nadoo on 01/10/2019.
 */

public class GridAdapter extends BaseAdapter{

    Context context;

    View view;
    LayoutInflater layoutInflater;
    int[] images =
            {
                    R.drawable.hat,
                    R.drawable.d,
                    R.drawable.eid0,
                    R.drawable.eid1,
                    R.drawable.eid2,
                    R.drawable.eid3,
                    R.drawable.eid4,
                    R.drawable.eid5,
                    R.drawable.eid6,
                    R.drawable.eid7,
                    R.drawable.eid8,
                    R.drawable.eid9,
                    R.drawable.volunteer,
                    R.drawable.nadiah,
                    R.drawable.islamic,
                    R.drawable.hm,
                    R.drawable.r0,
                    R.drawable.r1,
                    R.drawable.r2,
                    R.drawable.r3,
                    R.drawable.r4,
                    R.drawable.r5,
                    R.drawable.women};

    public GridAdapter(Context context) {
        this.context = context;

    }

    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if(convertView == null){
            view = new View(context);
            view = layoutInflater.inflate(R.layout.single_item, null);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            imageView.setImageResource(images[position]);
        }
        return view;
    }


}
